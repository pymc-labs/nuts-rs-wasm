# Register the per-linker ``rewrite_scan_inner_graph`` implementations consulted by
# the ``scan_inner_graph`` rewrite. Imported here (the linker classes are lightweight
# -- they do not pull in their runtimes) so they take effect whenever
# ``pytensor.scan`` is used.
import pytensor.scan.rewriting.inner_graph
from pytensor.scan.rewriting.db import (
    ScanEquilibriumGraphRewriter,
    scan_eqopt1,
    scan_eqopt2,
    scan_seqopt1,
)
from pytensor.scan.rewriting.inplace import ScanInplaceOptimizer
from pytensor.scan.rewriting.io import (
    scan_inline_invariant_constants,
    scan_merge_duplicate_inputs,
    scan_remove_unused,
)
from pytensor.scan.rewriting.merge import ScanMerge, scan_merge_inouts
from pytensor.scan.rewriting.push_out import (
    scan_push_out_add,
    scan_push_out_dot1,
    scan_push_out_non_seq,
    scan_push_out_seq,
)
from pytensor.scan.rewriting.trace import (
    scan_reduce_nsteps,
    scan_reduce_trace_no_prealloc,
    scan_reduce_trace_prealloc,
    scan_sit_sot_to_untraced,
)
