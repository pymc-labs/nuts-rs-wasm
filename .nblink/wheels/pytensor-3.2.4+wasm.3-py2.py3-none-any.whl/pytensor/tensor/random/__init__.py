# Initialize `RandomVariable` rewrites
import pytensor.tensor.random.rewriting
import pytensor.tensor.random.utils
from pytensor.tensor.random.basic import *
from pytensor.tensor.random.op import default_rng
from pytensor.tensor.random.utils import RandomStream
from pytensor.tensor.random.variable import rng, shared_rng
