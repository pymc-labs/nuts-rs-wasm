#   Copyright 2022 - 2026 The PyMC Labs Developers
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
"""Customer Choice module."""

from pymc_marketing.customer_choice import taste_profiles
from pymc_marketing.customer_choice.bayesian_blp import BayesianBLP
from pymc_marketing.customer_choice.consideration_set_logit import (
    ConsiderationSetMixedLogit,
)
from pymc_marketing.customer_choice.maxdiff import (
    MaxDiffMixedLogit,
    prepare_maxdiff_data,
)
from pymc_marketing.customer_choice.mixed_logit import MixedLogit
from pymc_marketing.customer_choice.mv_its import (
    MVITS,
    plot_product,
)
from pymc_marketing.customer_choice.synthetic_data import (
    generate_blp_panel,
    generate_maxdiff_conjoint_data,
    generate_maxdiff_data,
    generate_saturated_data,
    generate_unsaturated_data,
)

__all__ = [
    "MVITS",
    "BayesianBLP",
    "ConsiderationSetMixedLogit",
    "MaxDiffMixedLogit",
    "MixedLogit",
    "generate_blp_panel",
    "generate_maxdiff_conjoint_data",
    "generate_maxdiff_data",
    "generate_saturated_data",
    "generate_unsaturated_data",
    "plot_product",
    "prepare_maxdiff_data",
    "taste_profiles",
]
