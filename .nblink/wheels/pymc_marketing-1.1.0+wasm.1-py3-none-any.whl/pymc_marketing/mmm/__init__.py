#   Copyright 2022 - 2026 The PyMC Labs Developers
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
"""Marketing Mix Models (MMM)."""

from pymc_marketing.mmm import preprocessing, validating
from pymc_marketing.mmm.additive_effect import (
    ControlMuEffect,
    DataVarMuEffect,
    IncrementalitySpec,
    MediaMuEffect,
)
from pymc_marketing.mmm.budget_optimizer import (
    BudgetOptimizationResult,
    BudgetOptimizer,
    merge_inference_data,
    merge_models_and_idata,
)
from pymc_marketing.mmm.components.adstock import (
    AdstockTransformation,
    BinomialAdstock,
    DelayedAdstock,
    GeometricAdstock,
    NoAdstock,
    WeibullCDFAdstock,
    WeibullPDFAdstock,
)
from pymc_marketing.mmm.components.saturation import (
    HillSaturation,
    HillSaturationSigmoid,
    InverseScaledLogisticSaturation,
    LogisticSaturation,
    LogSaturation,
    MichaelisMentenSaturation,
    NoSaturation,
    RootSaturation,
    SaturationTransformation,
    TanhSaturation,
    TanhSaturationBaselined,
)
from pymc_marketing.mmm.fourier import MonthlyFourier, WeeklyFourier, YearlyFourier
from pymc_marketing.mmm.hsgp import (
    HSGP,
    CovFunc,
    HSGPPeriodic,
    PeriodicCovFunc,
    SoftPlusHSGP,
    approx_hsgp_hyperparams,
    create_complexity_penalizing_prior,
    create_constrained_inverse_gamma_prior,
    create_eta_prior,
    create_m_and_L_recommendations,
)
from pymc_marketing.mmm.incrementality import Incrementality
from pymc_marketing.mmm.linear_regression import FancyLinearRegression
from pymc_marketing.mmm.linear_trend import LinearTrend
from pymc_marketing.mmm.media_transformation import (
    MediaConfig,
    MediaConfigList,
    MediaTransformation,
)
from pymc_marketing.mmm.mmm import (
    MMM,
    BudgetOptimizerWrapper,
)
from pymc_marketing.mmm.optimization_variables import (
    OptimizationVariable,
    OptimizationVariables,
)
from pymc_marketing.mmm.plotting import MMMPlotSuiteFacade
from pymc_marketing.mmm.preprocessing import (
    preprocessing_method_X,
    preprocessing_method_y,
)
from pymc_marketing.mmm.scaling import (
    DataDerivedScaling,
    FixedScaling,
    Scaling,
    VariableScaling,
)
from pymc_marketing.mmm.sensitivity_analysis import SensitivityAnalysis
from pymc_marketing.mmm.time_slice_cross_validation import (
    TimeSliceCrossValidationResult,
    TimeSliceCrossValidator,
)
from pymc_marketing.mmm.types import MMMBuilder
from pymc_marketing.mmm.validating import validation_method_X, validation_method_y

__all__ = [
    "HSGP",
    "MMM",
    "AdstockTransformation",
    "BinomialAdstock",
    "BudgetOptimizationResult",
    "BudgetOptimizer",
    "BudgetOptimizerWrapper",
    "ControlMuEffect",
    "CovFunc",
    "DataDerivedScaling",
    "DataVarMuEffect",
    "DelayedAdstock",
    "FancyLinearRegression",
    "FixedScaling",
    "GeometricAdstock",
    "HSGPPeriodic",
    "HillSaturation",
    "HillSaturationSigmoid",
    "Incrementality",
    "IncrementalitySpec",
    "InverseScaledLogisticSaturation",
    "LinearTrend",
    "LogSaturation",
    "LogisticSaturation",
    "MMMBuilder",
    "MMMPlotSuiteFacade",
    "MediaConfig",
    "MediaConfigList",
    "MediaMuEffect",
    "MediaTransformation",
    "MichaelisMentenSaturation",
    "MonthlyFourier",
    "NoAdstock",
    "NoSaturation",
    "OptimizationVariable",
    "OptimizationVariables",
    "PeriodicCovFunc",
    "RootSaturation",
    "SaturationTransformation",
    "Scaling",
    "SensitivityAnalysis",
    "SoftPlusHSGP",
    "TanhSaturation",
    "TanhSaturationBaselined",
    "TimeSliceCrossValidationResult",
    "TimeSliceCrossValidator",
    "VariableScaling",
    "WeeklyFourier",
    "WeibullCDFAdstock",
    "WeibullPDFAdstock",
    "YearlyFourier",
    "approx_hsgp_hyperparams",
    "create_complexity_penalizing_prior",
    "create_constrained_inverse_gamma_prior",
    "create_eta_prior",
    "create_m_and_L_recommendations",
    "merge_inference_data",
    "merge_models_and_idata",
    "preprocessing",
    "preprocessing_method_X",
    "preprocessing_method_y",
    "validating",
    "validation_method_X",
    "validation_method_y",
]
