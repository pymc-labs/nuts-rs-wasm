#   Copyright 2022 - 2026 The PyMC Labs Developers
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
"""MMM plotting package — namespace-based plot suite."""

from pymc_marketing.mmm.plotting.budget import BudgetPlots
from pymc_marketing.mmm.plotting.cv import MMMCVPlotSuite
from pymc_marketing.mmm.plotting.decomposition import DecompositionPlots
from pymc_marketing.mmm.plotting.diagnostics import DiagnosticsPlots
from pymc_marketing.mmm.plotting.sensitivity import SensitivityPlots
from pymc_marketing.mmm.plotting.suite import MMMPlotSuiteFacade
from pymc_marketing.mmm.plotting.transformations import TransformationPlots

__all__ = [
    "BudgetPlots",
    "DecompositionPlots",
    "DiagnosticsPlots",
    "MMMCVPlotSuite",
    "MMMPlotSuiteFacade",
    "SensitivityPlots",
    "TransformationPlots",
]
